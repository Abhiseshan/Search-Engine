# Search-Engine

Front end for the search engine. Please create branches while working on the code. Create a pull request into master if you want to merge anything. Thanks.
